// Generated from LTLParser.g4 by ANTLR 4.8

package owl.grammar;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link LTLParser}.
 */
public interface LTLParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link LTLParser#formula}.
	 * @param ctx the parse tree
	 */
	void enterFormula(LTLParser.FormulaContext ctx);
	/**
	 * Exit a parse tree produced by {@link LTLParser#formula}.
	 * @param ctx the parse tree
	 */
	void exitFormula(LTLParser.FormulaContext ctx);
	/**
	 * Enter a parse tree produced by {@link LTLParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(LTLParser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link LTLParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(LTLParser.ExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link LTLParser#orExpression}.
	 * @param ctx the parse tree
	 */
	void enterOrExpression(LTLParser.OrExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link LTLParser#orExpression}.
	 * @param ctx the parse tree
	 */
	void exitOrExpression(LTLParser.OrExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link LTLParser#andExpression}.
	 * @param ctx the parse tree
	 */
	void enterAndExpression(LTLParser.AndExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link LTLParser#andExpression}.
	 * @param ctx the parse tree
	 */
	void exitAndExpression(LTLParser.AndExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code binaryOperation}
	 * labeled alternative in {@link LTLParser#binaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterBinaryOperation(LTLParser.BinaryOperationContext ctx);
	/**
	 * Exit a parse tree produced by the {@code binaryOperation}
	 * labeled alternative in {@link LTLParser#binaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitBinaryOperation(LTLParser.BinaryOperationContext ctx);
	/**
	 * Enter a parse tree produced by the {@code binaryUnary}
	 * labeled alternative in {@link LTLParser#binaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterBinaryUnary(LTLParser.BinaryUnaryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code binaryUnary}
	 * labeled alternative in {@link LTLParser#binaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitBinaryUnary(LTLParser.BinaryUnaryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryOperation}
	 * labeled alternative in {@link LTLParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOperation(LTLParser.UnaryOperationContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryOperation}
	 * labeled alternative in {@link LTLParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOperation(LTLParser.UnaryOperationContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryAtom}
	 * labeled alternative in {@link LTLParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterUnaryAtom(LTLParser.UnaryAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryAtom}
	 * labeled alternative in {@link LTLParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitUnaryAtom(LTLParser.UnaryAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolean}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void enterBoolean(LTLParser.BooleanContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolean}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void exitBoolean(LTLParser.BooleanContext ctx);
	/**
	 * Enter a parse tree produced by the {@code variable}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void enterVariable(LTLParser.VariableContext ctx);
	/**
	 * Exit a parse tree produced by the {@code variable}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void exitVariable(LTLParser.VariableContext ctx);
	/**
	 * Enter a parse tree produced by the {@code singleQuotedVariable}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void enterSingleQuotedVariable(LTLParser.SingleQuotedVariableContext ctx);
	/**
	 * Exit a parse tree produced by the {@code singleQuotedVariable}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void exitSingleQuotedVariable(LTLParser.SingleQuotedVariableContext ctx);
	/**
	 * Enter a parse tree produced by the {@code doubleQuotedVariable}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void enterDoubleQuotedVariable(LTLParser.DoubleQuotedVariableContext ctx);
	/**
	 * Exit a parse tree produced by the {@code doubleQuotedVariable}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void exitDoubleQuotedVariable(LTLParser.DoubleQuotedVariableContext ctx);
	/**
	 * Enter a parse tree produced by the {@code nested}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void enterNested(LTLParser.NestedContext ctx);
	/**
	 * Exit a parse tree produced by the {@code nested}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 */
	void exitNested(LTLParser.NestedContext ctx);
	/**
	 * Enter a parse tree produced by {@link LTLParser#unaryOp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOp(LTLParser.UnaryOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link LTLParser#unaryOp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOp(LTLParser.UnaryOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link LTLParser#binaryOp}.
	 * @param ctx the parse tree
	 */
	void enterBinaryOp(LTLParser.BinaryOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link LTLParser#binaryOp}.
	 * @param ctx the parse tree
	 */
	void exitBinaryOp(LTLParser.BinaryOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link LTLParser#bool}.
	 * @param ctx the parse tree
	 */
	void enterBool(LTLParser.BoolContext ctx);
	/**
	 * Exit a parse tree produced by {@link LTLParser#bool}.
	 * @param ctx the parse tree
	 */
	void exitBool(LTLParser.BoolContext ctx);
}