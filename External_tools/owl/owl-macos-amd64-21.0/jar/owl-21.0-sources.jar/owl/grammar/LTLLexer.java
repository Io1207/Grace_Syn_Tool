// Generated from LTLLexer.g4 by ANTLR 4.8

package owl.grammar;

import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class LTLLexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		TRUE=1, FALSE=2, NOT=3, IMP=4, BIIMP=5, XOR=6, AND=7, OR=8, FINALLY=9, 
		GLOBALLY=10, NEXT=11, UNTIL=12, WUNTIL=13, RELEASE=14, SRELEASE=15, LPAREN=16, 
		RPAREN=17, LDQUOTE=18, LSQUOTE=19, VARIABLE=20, SKIP_DEF=21, RDQUOTE=22, 
		DOUBLE_QUOTED_VARIABLE=23, RSQUOTE=24, SINGLE_QUOTED_VARIABLE=25, ERROR=26;
	public static final int
		DOUBLE_QUOTED=1, SINGLE_QUOTED=2;
	public static String[] channelNames = {
		"DEFAULT_TOKEN_CHANNEL", "HIDDEN"
	};

	public static String[] modeNames = {
		"DEFAULT_MODE", "DOUBLE_QUOTED", "SINGLE_QUOTED"
	};

	private static String[] makeRuleNames() {
		return new String[] {
			"TRUE", "FALSE", "NOT", "IMP", "BIIMP", "XOR", "AND", "OR", "FINALLY", 
			"GLOBALLY", "NEXT", "UNTIL", "WUNTIL", "RELEASE", "SRELEASE", "LPAREN", 
			"RPAREN", "LDQUOTE", "LSQUOTE", "VARIABLE", "WHITESPACE", "SKIP_DEF", 
			"RDQUOTE", "DOUBLE_QUOTED_VARIABLE", "RSQUOTE", "SINGLE_QUOTED_VARIABLE", 
			"ERROR"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, "'F'", "'G'", "'X'", 
			"'U'", "'W'", "'R'", "'M'", "'('", "')'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "TRUE", "FALSE", "NOT", "IMP", "BIIMP", "XOR", "AND", "OR", "FINALLY", 
			"GLOBALLY", "NEXT", "UNTIL", "WUNTIL", "RELEASE", "SRELEASE", "LPAREN", 
			"RPAREN", "LDQUOTE", "LSQUOTE", "VARIABLE", "SKIP_DEF", "RDQUOTE", "DOUBLE_QUOTED_VARIABLE", 
			"RSQUOTE", "SINGLE_QUOTED_VARIABLE", "ERROR"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}


	public LTLLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "LTLLexer.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getChannelNames() { return channelNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2\34\u00c6\b\1\b\1"+
		"\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4"+
		"\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t"+
		"\21\4\22\t\22\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t"+
		"\30\4\31\t\31\4\32\t\32\4\33\t\33\4\34\t\34\3\2\3\2\3\2\3\2\3\2\3\2\3"+
		"\2\5\2C\n\2\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3M\n\3\3\4\3\4\3\4\3\4\5"+
		"\4S\n\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\5\5b\n\5\3"+
		"\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6o\n\6\3\7\3\7\3\7\3\7\3"+
		"\7\3\7\3\7\5\7x\n\7\3\b\3\b\3\b\3\b\3\b\3\b\5\b\u0080\n\b\3\t\3\t\3\t"+
		"\3\t\3\t\5\t\u0087\n\t\3\n\3\n\3\13\3\13\3\f\3\f\3\r\3\r\3\16\3\16\3\17"+
		"\3\17\3\20\3\20\3\21\3\21\3\22\3\22\3\23\3\23\3\23\3\23\3\24\3\24\3\24"+
		"\3\24\3\25\3\25\7\25\u00a5\n\25\f\25\16\25\u00a8\13\25\3\26\6\26\u00ab"+
		"\n\26\r\26\16\26\u00ac\3\27\3\27\3\27\3\27\3\30\3\30\3\30\3\30\3\31\6"+
		"\31\u00b8\n\31\r\31\16\31\u00b9\3\32\3\32\3\32\3\32\3\33\6\33\u00c1\n"+
		"\33\r\33\16\33\u00c2\3\34\3\34\2\2\35\5\3\7\4\t\5\13\6\r\7\17\b\21\t\23"+
		"\n\25\13\27\f\31\r\33\16\35\17\37\20!\21#\22%\23\'\24)\25+\26-\2/\27\61"+
		"\30\63\31\65\32\67\339\34\5\2\3\4\7\5\2NNaac|\6\2\62;C\\aac|\5\2\13\f"+
		"\16\17\"\"\3\2$$\3\2))\2\u00d7\2\5\3\2\2\2\2\7\3\2\2\2\2\t\3\2\2\2\2\13"+
		"\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2\2\2\21\3\2\2\2\2\23\3\2\2\2\2\25\3\2\2"+
		"\2\2\27\3\2\2\2\2\31\3\2\2\2\2\33\3\2\2\2\2\35\3\2\2\2\2\37\3\2\2\2\2"+
		"!\3\2\2\2\2#\3\2\2\2\2%\3\2\2\2\2\'\3\2\2\2\2)\3\2\2\2\2+\3\2\2\2\2/\3"+
		"\2\2\2\29\3\2\2\2\3\61\3\2\2\2\3\63\3\2\2\2\4\65\3\2\2\2\4\67\3\2\2\2"+
		"\5B\3\2\2\2\7L\3\2\2\2\tR\3\2\2\2\13a\3\2\2\2\rn\3\2\2\2\17w\3\2\2\2\21"+
		"\177\3\2\2\2\23\u0086\3\2\2\2\25\u0088\3\2\2\2\27\u008a\3\2\2\2\31\u008c"+
		"\3\2\2\2\33\u008e\3\2\2\2\35\u0090\3\2\2\2\37\u0092\3\2\2\2!\u0094\3\2"+
		"\2\2#\u0096\3\2\2\2%\u0098\3\2\2\2\'\u009a\3\2\2\2)\u009e\3\2\2\2+\u00a2"+
		"\3\2\2\2-\u00aa\3\2\2\2/\u00ae\3\2\2\2\61\u00b2\3\2\2\2\63\u00b7\3\2\2"+
		"\2\65\u00bb\3\2\2\2\67\u00c0\3\2\2\29\u00c4\3\2\2\2;<\7v\2\2<C\7v\2\2"+
		"=>\7v\2\2>?\7t\2\2?@\7w\2\2@C\7g\2\2AC\7\63\2\2B;\3\2\2\2B=\3\2\2\2BA"+
		"\3\2\2\2C\6\3\2\2\2DE\7h\2\2EM\7h\2\2FG\7h\2\2GH\7c\2\2HI\7n\2\2IJ\7u"+
		"\2\2JM\7g\2\2KM\7\62\2\2LD\3\2\2\2LF\3\2\2\2LK\3\2\2\2M\b\3\2\2\2NS\7"+
		"#\2\2OP\7P\2\2PQ\7Q\2\2QS\7V\2\2RN\3\2\2\2RO\3\2\2\2S\n\3\2\2\2TU\7/\2"+
		"\2Ub\7@\2\2VW\7/\2\2WX\7/\2\2Xb\7@\2\2YZ\7?\2\2Zb\7@\2\2[\\\7?\2\2\\]"+
		"\7?\2\2]b\7@\2\2^_\7K\2\2_`\7O\2\2`b\7R\2\2aT\3\2\2\2aV\3\2\2\2aY\3\2"+
		"\2\2a[\3\2\2\2a^\3\2\2\2b\f\3\2\2\2cd\7>\2\2de\7/\2\2eo\7@\2\2fg\7>\2"+
		"\2gh\7?\2\2ho\7@\2\2ij\7D\2\2jk\7K\2\2kl\7K\2\2lm\7O\2\2mo\7R\2\2nc\3"+
		"\2\2\2nf\3\2\2\2ni\3\2\2\2o\16\3\2\2\2px\7`\2\2qr\7Z\2\2rs\7Q\2\2sx\7"+
		"T\2\2tu\7z\2\2uv\7q\2\2vx\7t\2\2wp\3\2\2\2wq\3\2\2\2wt\3\2\2\2x\20\3\2"+
		"\2\2yz\7(\2\2z\u0080\7(\2\2{\u0080\7(\2\2|}\7C\2\2}~\7P\2\2~\u0080\7F"+
		"\2\2\177y\3\2\2\2\177{\3\2\2\2\177|\3\2\2\2\u0080\22\3\2\2\2\u0081\u0082"+
		"\7~\2\2\u0082\u0087\7~\2\2\u0083\u0087\7~\2\2\u0084\u0085\7Q\2\2\u0085"+
		"\u0087\7T\2\2\u0086\u0081\3\2\2\2\u0086\u0083\3\2\2\2\u0086\u0084\3\2"+
		"\2\2\u0087\24\3\2\2\2\u0088\u0089\7H\2\2\u0089\26\3\2\2\2\u008a\u008b"+
		"\7I\2\2\u008b\30\3\2\2\2\u008c\u008d\7Z\2\2\u008d\32\3\2\2\2\u008e\u008f"+
		"\7W\2\2\u008f\34\3\2\2\2\u0090\u0091\7Y\2\2\u0091\36\3\2\2\2\u0092\u0093"+
		"\7T\2\2\u0093 \3\2\2\2\u0094\u0095\7O\2\2\u0095\"\3\2\2\2\u0096\u0097"+
		"\7*\2\2\u0097$\3\2\2\2\u0098\u0099\7+\2\2\u0099&\3\2\2\2\u009a\u009b\7"+
		"$\2\2\u009b\u009c\3\2\2\2\u009c\u009d\b\23\2\2\u009d(\3\2\2\2\u009e\u009f"+
		"\7)\2\2\u009f\u00a0\3\2\2\2\u00a0\u00a1\b\24\3\2\u00a1*\3\2\2\2\u00a2"+
		"\u00a6\t\2\2\2\u00a3\u00a5\t\3\2\2\u00a4\u00a3\3\2\2\2\u00a5\u00a8\3\2"+
		"\2\2\u00a6\u00a4\3\2\2\2\u00a6\u00a7\3\2\2\2\u00a7,\3\2\2\2\u00a8\u00a6"+
		"\3\2\2\2\u00a9\u00ab\t\4\2\2\u00aa\u00a9\3\2\2\2\u00ab\u00ac\3\2\2\2\u00ac"+
		"\u00aa\3\2\2\2\u00ac\u00ad\3\2\2\2\u00ad.\3\2\2\2\u00ae\u00af\5-\26\2"+
		"\u00af\u00b0\3\2\2\2\u00b0\u00b1\b\27\4\2\u00b1\60\3\2\2\2\u00b2\u00b3"+
		"\7$\2\2\u00b3\u00b4\3\2\2\2\u00b4\u00b5\b\30\5\2\u00b5\62\3\2\2\2\u00b6"+
		"\u00b8\n\5\2\2\u00b7\u00b6\3\2\2\2\u00b8\u00b9\3\2\2\2\u00b9\u00b7\3\2"+
		"\2\2\u00b9\u00ba\3\2\2\2\u00ba\64\3\2\2\2\u00bb\u00bc\7)\2\2\u00bc\u00bd"+
		"\3\2\2\2\u00bd\u00be\b\32\5\2\u00be\66\3\2\2\2\u00bf\u00c1\n\6\2\2\u00c0"+
		"\u00bf\3\2\2\2\u00c1\u00c2\3\2\2\2\u00c2\u00c0\3\2\2\2\u00c2\u00c3\3\2"+
		"\2\2\u00c38\3\2\2\2\u00c4\u00c5\13\2\2\2\u00c5:\3\2\2\2\21\2\3\4BLRan"+
		"w\177\u0086\u00a6\u00ac\u00b9\u00c2\6\4\3\2\4\4\2\b\2\2\4\2\2";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}