// Generated from LTLParser.g4 by ANTLR 4.8

package owl.grammar;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link LTLParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface LTLParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link LTLParser#formula}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFormula(LTLParser.FormulaContext ctx);
	/**
	 * Visit a parse tree produced by {@link LTLParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression(LTLParser.ExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link LTLParser#orExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrExpression(LTLParser.OrExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link LTLParser#andExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAndExpression(LTLParser.AndExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryOperation}
	 * labeled alternative in {@link LTLParser#binaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOperation(LTLParser.BinaryOperationContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryUnary}
	 * labeled alternative in {@link LTLParser#binaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryUnary(LTLParser.BinaryUnaryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryOperation}
	 * labeled alternative in {@link LTLParser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryOperation(LTLParser.UnaryOperationContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryAtom}
	 * labeled alternative in {@link LTLParser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryAtom(LTLParser.UnaryAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolean}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolean(LTLParser.BooleanContext ctx);
	/**
	 * Visit a parse tree produced by the {@code variable}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariable(LTLParser.VariableContext ctx);
	/**
	 * Visit a parse tree produced by the {@code singleQuotedVariable}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingleQuotedVariable(LTLParser.SingleQuotedVariableContext ctx);
	/**
	 * Visit a parse tree produced by the {@code doubleQuotedVariable}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDoubleQuotedVariable(LTLParser.DoubleQuotedVariableContext ctx);
	/**
	 * Visit a parse tree produced by the {@code nested}
	 * labeled alternative in {@link LTLParser#atomExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNested(LTLParser.NestedContext ctx);
	/**
	 * Visit a parse tree produced by {@link LTLParser#unaryOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryOp(LTLParser.UnaryOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link LTLParser#binaryOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOp(LTLParser.BinaryOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link LTLParser#bool}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBool(LTLParser.BoolContext ctx);
}