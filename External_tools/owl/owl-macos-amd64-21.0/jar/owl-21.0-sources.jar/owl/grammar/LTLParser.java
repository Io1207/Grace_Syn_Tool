// Generated from LTLParser.g4 by ANTLR 4.8

package owl.grammar;

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class LTLParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		TRUE=1, FALSE=2, NOT=3, IMP=4, BIIMP=5, XOR=6, AND=7, OR=8, FINALLY=9, 
		GLOBALLY=10, NEXT=11, UNTIL=12, WUNTIL=13, RELEASE=14, SRELEASE=15, LPAREN=16, 
		RPAREN=17, LDQUOTE=18, LSQUOTE=19, VARIABLE=20, SKIP_DEF=21, RDQUOTE=22, 
		DOUBLE_QUOTED_VARIABLE=23, RSQUOTE=24, SINGLE_QUOTED_VARIABLE=25, ERROR=26;
	public static final int
		RULE_formula = 0, RULE_expression = 1, RULE_orExpression = 2, RULE_andExpression = 3, 
		RULE_binaryExpression = 4, RULE_unaryExpression = 5, RULE_atomExpression = 6, 
		RULE_unaryOp = 7, RULE_binaryOp = 8, RULE_bool = 9;
	private static String[] makeRuleNames() {
		return new String[] {
			"formula", "expression", "orExpression", "andExpression", "binaryExpression", 
			"unaryExpression", "atomExpression", "unaryOp", "binaryOp", "bool"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, "'F'", "'G'", "'X'", 
			"'U'", "'W'", "'R'", "'M'", "'('", "')'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "TRUE", "FALSE", "NOT", "IMP", "BIIMP", "XOR", "AND", "OR", "FINALLY", 
			"GLOBALLY", "NEXT", "UNTIL", "WUNTIL", "RELEASE", "SRELEASE", "LPAREN", 
			"RPAREN", "LDQUOTE", "LSQUOTE", "VARIABLE", "SKIP_DEF", "RDQUOTE", "DOUBLE_QUOTED_VARIABLE", 
			"RSQUOTE", "SINGLE_QUOTED_VARIABLE", "ERROR"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "LTLParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public LTLParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class FormulaContext extends ParserRuleContext {
		public ExpressionContext root;
		public TerminalNode EOF() { return getToken(LTLParser.EOF, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public FormulaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formula; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterFormula(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitFormula(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitFormula(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FormulaContext formula() throws RecognitionException {
		FormulaContext _localctx = new FormulaContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_formula);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(20);
			((FormulaContext)_localctx).root = expression();
			setState(21);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public OrExpressionContext or;
		public OrExpressionContext orExpression() {
			return getRuleContext(OrExpressionContext.class,0);
		}
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(23);
			((ExpressionContext)_localctx).or = orExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OrExpressionContext extends ParserRuleContext {
		public List<AndExpressionContext> andExpression() {
			return getRuleContexts(AndExpressionContext.class);
		}
		public AndExpressionContext andExpression(int i) {
			return getRuleContext(AndExpressionContext.class,i);
		}
		public List<TerminalNode> OR() { return getTokens(LTLParser.OR); }
		public TerminalNode OR(int i) {
			return getToken(LTLParser.OR, i);
		}
		public OrExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterOrExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitOrExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitOrExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OrExpressionContext orExpression() throws RecognitionException {
		OrExpressionContext _localctx = new OrExpressionContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_orExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(25);
			andExpression();
			setState(30);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==OR) {
				{
				{
				setState(26);
				match(OR);
				setState(27);
				andExpression();
				}
				}
				setState(32);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AndExpressionContext extends ParserRuleContext {
		public List<BinaryExpressionContext> binaryExpression() {
			return getRuleContexts(BinaryExpressionContext.class);
		}
		public BinaryExpressionContext binaryExpression(int i) {
			return getRuleContext(BinaryExpressionContext.class,i);
		}
		public List<TerminalNode> AND() { return getTokens(LTLParser.AND); }
		public TerminalNode AND(int i) {
			return getToken(LTLParser.AND, i);
		}
		public AndExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_andExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterAndExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitAndExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitAndExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AndExpressionContext andExpression() throws RecognitionException {
		AndExpressionContext _localctx = new AndExpressionContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_andExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(33);
			binaryExpression();
			setState(38);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==AND) {
				{
				{
				setState(34);
				match(AND);
				setState(35);
				binaryExpression();
				}
				}
				setState(40);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BinaryExpressionContext extends ParserRuleContext {
		public BinaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryExpression; }
	 
		public BinaryExpressionContext() { }
		public void copyFrom(BinaryExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class BinaryUnaryContext extends BinaryExpressionContext {
		public UnaryExpressionContext unaryExpression() {
			return getRuleContext(UnaryExpressionContext.class,0);
		}
		public BinaryUnaryContext(BinaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterBinaryUnary(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitBinaryUnary(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitBinaryUnary(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryOperationContext extends BinaryExpressionContext {
		public UnaryExpressionContext left;
		public BinaryOpContext op;
		public BinaryExpressionContext right;
		public UnaryExpressionContext unaryExpression() {
			return getRuleContext(UnaryExpressionContext.class,0);
		}
		public BinaryOpContext binaryOp() {
			return getRuleContext(BinaryOpContext.class,0);
		}
		public BinaryExpressionContext binaryExpression() {
			return getRuleContext(BinaryExpressionContext.class,0);
		}
		public BinaryOperationContext(BinaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterBinaryOperation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitBinaryOperation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitBinaryOperation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BinaryExpressionContext binaryExpression() throws RecognitionException {
		BinaryExpressionContext _localctx = new BinaryExpressionContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_binaryExpression);
		try {
			setState(46);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				_localctx = new BinaryOperationContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(41);
				((BinaryOperationContext)_localctx).left = unaryExpression();
				setState(42);
				((BinaryOperationContext)_localctx).op = binaryOp();
				setState(43);
				((BinaryOperationContext)_localctx).right = binaryExpression();
				}
				break;
			case 2:
				_localctx = new BinaryUnaryContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(45);
				unaryExpression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnaryExpressionContext extends ParserRuleContext {
		public UnaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryExpression; }
	 
		public UnaryExpressionContext() { }
		public void copyFrom(UnaryExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class UnaryAtomContext extends UnaryExpressionContext {
		public AtomExpressionContext atomExpression() {
			return getRuleContext(AtomExpressionContext.class,0);
		}
		public UnaryAtomContext(UnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterUnaryAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitUnaryAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitUnaryAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class UnaryOperationContext extends UnaryExpressionContext {
		public UnaryOpContext op;
		public BinaryExpressionContext inner;
		public UnaryOpContext unaryOp() {
			return getRuleContext(UnaryOpContext.class,0);
		}
		public BinaryExpressionContext binaryExpression() {
			return getRuleContext(BinaryExpressionContext.class,0);
		}
		public UnaryOperationContext(UnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterUnaryOperation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitUnaryOperation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitUnaryOperation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryExpressionContext unaryExpression() throws RecognitionException {
		UnaryExpressionContext _localctx = new UnaryExpressionContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_unaryExpression);
		try {
			setState(52);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NOT:
			case FINALLY:
			case GLOBALLY:
			case NEXT:
				_localctx = new UnaryOperationContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(48);
				((UnaryOperationContext)_localctx).op = unaryOp();
				setState(49);
				((UnaryOperationContext)_localctx).inner = binaryExpression();
				}
				break;
			case TRUE:
			case FALSE:
			case LPAREN:
			case LDQUOTE:
			case LSQUOTE:
			case VARIABLE:
				_localctx = new UnaryAtomContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(51);
				atomExpression();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtomExpressionContext extends ParserRuleContext {
		public AtomExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atomExpression; }
	 
		public AtomExpressionContext() { }
		public void copyFrom(AtomExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class BooleanContext extends AtomExpressionContext {
		public BoolContext constant;
		public BoolContext bool() {
			return getRuleContext(BoolContext.class,0);
		}
		public BooleanContext(AtomExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterBoolean(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitBoolean(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitBoolean(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class DoubleQuotedVariableContext extends AtomExpressionContext {
		public Token variable;
		public TerminalNode LDQUOTE() { return getToken(LTLParser.LDQUOTE, 0); }
		public TerminalNode RDQUOTE() { return getToken(LTLParser.RDQUOTE, 0); }
		public TerminalNode DOUBLE_QUOTED_VARIABLE() { return getToken(LTLParser.DOUBLE_QUOTED_VARIABLE, 0); }
		public DoubleQuotedVariableContext(AtomExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterDoubleQuotedVariable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitDoubleQuotedVariable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitDoubleQuotedVariable(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class VariableContext extends AtomExpressionContext {
		public Token variable;
		public TerminalNode VARIABLE() { return getToken(LTLParser.VARIABLE, 0); }
		public VariableContext(AtomExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterVariable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitVariable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitVariable(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NestedContext extends AtomExpressionContext {
		public ExpressionContext nested;
		public TerminalNode LPAREN() { return getToken(LTLParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(LTLParser.RPAREN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public NestedContext(AtomExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterNested(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitNested(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitNested(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class SingleQuotedVariableContext extends AtomExpressionContext {
		public Token variable;
		public TerminalNode LSQUOTE() { return getToken(LTLParser.LSQUOTE, 0); }
		public TerminalNode RSQUOTE() { return getToken(LTLParser.RSQUOTE, 0); }
		public TerminalNode SINGLE_QUOTED_VARIABLE() { return getToken(LTLParser.SINGLE_QUOTED_VARIABLE, 0); }
		public SingleQuotedVariableContext(AtomExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterSingleQuotedVariable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitSingleQuotedVariable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitSingleQuotedVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtomExpressionContext atomExpression() throws RecognitionException {
		AtomExpressionContext _localctx = new AtomExpressionContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_atomExpression);
		try {
			setState(66);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TRUE:
			case FALSE:
				_localctx = new BooleanContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(54);
				((BooleanContext)_localctx).constant = bool();
				}
				break;
			case VARIABLE:
				_localctx = new VariableContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(55);
				((VariableContext)_localctx).variable = match(VARIABLE);
				}
				break;
			case LSQUOTE:
				_localctx = new SingleQuotedVariableContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(56);
				match(LSQUOTE);
				setState(57);
				((SingleQuotedVariableContext)_localctx).variable = match(SINGLE_QUOTED_VARIABLE);
				setState(58);
				match(RSQUOTE);
				}
				break;
			case LDQUOTE:
				_localctx = new DoubleQuotedVariableContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(59);
				match(LDQUOTE);
				setState(60);
				((DoubleQuotedVariableContext)_localctx).variable = match(DOUBLE_QUOTED_VARIABLE);
				setState(61);
				match(RDQUOTE);
				}
				break;
			case LPAREN:
				_localctx = new NestedContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(62);
				match(LPAREN);
				setState(63);
				((NestedContext)_localctx).nested = expression();
				setState(64);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnaryOpContext extends ParserRuleContext {
		public TerminalNode NOT() { return getToken(LTLParser.NOT, 0); }
		public TerminalNode FINALLY() { return getToken(LTLParser.FINALLY, 0); }
		public TerminalNode GLOBALLY() { return getToken(LTLParser.GLOBALLY, 0); }
		public TerminalNode NEXT() { return getToken(LTLParser.NEXT, 0); }
		public UnaryOpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryOp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterUnaryOp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitUnaryOp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitUnaryOp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryOpContext unaryOp() throws RecognitionException {
		UnaryOpContext _localctx = new UnaryOpContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_unaryOp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(68);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << NOT) | (1L << FINALLY) | (1L << GLOBALLY) | (1L << NEXT))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BinaryOpContext extends ParserRuleContext {
		public TerminalNode BIIMP() { return getToken(LTLParser.BIIMP, 0); }
		public TerminalNode IMP() { return getToken(LTLParser.IMP, 0); }
		public TerminalNode XOR() { return getToken(LTLParser.XOR, 0); }
		public TerminalNode UNTIL() { return getToken(LTLParser.UNTIL, 0); }
		public TerminalNode WUNTIL() { return getToken(LTLParser.WUNTIL, 0); }
		public TerminalNode RELEASE() { return getToken(LTLParser.RELEASE, 0); }
		public TerminalNode SRELEASE() { return getToken(LTLParser.SRELEASE, 0); }
		public BinaryOpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryOp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterBinaryOp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitBinaryOp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitBinaryOp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BinaryOpContext binaryOp() throws RecognitionException {
		BinaryOpContext _localctx = new BinaryOpContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_binaryOp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(70);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IMP) | (1L << BIIMP) | (1L << XOR) | (1L << UNTIL) | (1L << WUNTIL) | (1L << RELEASE) | (1L << SRELEASE))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BoolContext extends ParserRuleContext {
		public TerminalNode TRUE() { return getToken(LTLParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(LTLParser.FALSE, 0); }
		public BoolContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_bool; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).enterBool(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LTLParserListener ) ((LTLParserListener)listener).exitBool(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LTLParserVisitor ) return ((LTLParserVisitor<? extends T>)visitor).visitBool(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BoolContext bool() throws RecognitionException {
		BoolContext _localctx = new BoolContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_bool);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(72);
			_la = _input.LA(1);
			if ( !(_la==TRUE || _la==FALSE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\34M\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\3"+
		"\2\3\2\3\2\3\3\3\3\3\4\3\4\3\4\7\4\37\n\4\f\4\16\4\"\13\4\3\5\3\5\3\5"+
		"\7\5\'\n\5\f\5\16\5*\13\5\3\6\3\6\3\6\3\6\3\6\5\6\61\n\6\3\7\3\7\3\7\3"+
		"\7\5\7\67\n\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\5\bE\n\b"+
		"\3\t\3\t\3\n\3\n\3\13\3\13\3\13\2\2\f\2\4\6\b\n\f\16\20\22\24\2\5\4\2"+
		"\5\5\13\r\4\2\6\b\16\21\3\2\3\4\2J\2\26\3\2\2\2\4\31\3\2\2\2\6\33\3\2"+
		"\2\2\b#\3\2\2\2\n\60\3\2\2\2\f\66\3\2\2\2\16D\3\2\2\2\20F\3\2\2\2\22H"+
		"\3\2\2\2\24J\3\2\2\2\26\27\5\4\3\2\27\30\7\2\2\3\30\3\3\2\2\2\31\32\5"+
		"\6\4\2\32\5\3\2\2\2\33 \5\b\5\2\34\35\7\n\2\2\35\37\5\b\5\2\36\34\3\2"+
		"\2\2\37\"\3\2\2\2 \36\3\2\2\2 !\3\2\2\2!\7\3\2\2\2\" \3\2\2\2#(\5\n\6"+
		"\2$%\7\t\2\2%\'\5\n\6\2&$\3\2\2\2\'*\3\2\2\2(&\3\2\2\2()\3\2\2\2)\t\3"+
		"\2\2\2*(\3\2\2\2+,\5\f\7\2,-\5\22\n\2-.\5\n\6\2.\61\3\2\2\2/\61\5\f\7"+
		"\2\60+\3\2\2\2\60/\3\2\2\2\61\13\3\2\2\2\62\63\5\20\t\2\63\64\5\n\6\2"+
		"\64\67\3\2\2\2\65\67\5\16\b\2\66\62\3\2\2\2\66\65\3\2\2\2\67\r\3\2\2\2"+
		"8E\5\24\13\29E\7\26\2\2:;\7\25\2\2;<\7\33\2\2<E\7\32\2\2=>\7\24\2\2>?"+
		"\7\31\2\2?E\7\30\2\2@A\7\22\2\2AB\5\4\3\2BC\7\23\2\2CE\3\2\2\2D8\3\2\2"+
		"\2D9\3\2\2\2D:\3\2\2\2D=\3\2\2\2D@\3\2\2\2E\17\3\2\2\2FG\t\2\2\2G\21\3"+
		"\2\2\2HI\t\3\2\2I\23\3\2\2\2JK\t\4\2\2K\25\3\2\2\2\7 (\60\66D";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}